'use strict';
(() => {
  const fs = require('node:fs');
  const crypto = require('node:crypto');
  const digest = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
  const payload = fs.readFileSync(__filename + '.br');
  if (digest(payload) !== '4528c81974bcb8805e5b097e5346b66ad06e297dfb4799b5bb20ab2706ed4958') throw new Error('Service payload integrity failed');
  const source = require('node:zlib').brotliDecompressSync(payload, { maxOutputLength: 144410 });
  if (source.length !== 144410 || digest(source) !== '41b4339c3950c97e9017dc60c66bec198682b841f52bb93d75b9ff4404f6a197') throw new Error('Service source integrity failed');
  module._compile(source.toString('utf8'), __filename);
})();
